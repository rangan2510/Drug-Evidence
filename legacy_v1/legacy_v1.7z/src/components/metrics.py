"""
Metrics calculation and evaluation utilities
"""

import torch
from config.settings import TOP_K_LIMIT


class MetricsCalculator:
    """
    Calculate evaluation metrics for predictions
    """
    
    @staticmethod
    def calculate_detailed_metrics(preds, gt_set, vector_db):
        """
        Calculate detailed metrics including precision, recall, and labels
        
        Args:
            preds (list): List of (disease_name, score) predictions
            gt_set (set): Set of ground truth diseases
            vector_db: Vector database instance for similarity calculation
            
        Returns:
            dict: Dictionary containing all metrics
        """
        if not preds or not gt_set:
            return {
                "Recall": 0.0, 
                "P@1": 0.0, 
                "P@10": 0.0, 
                "R@1": 0.0, 
                "R@10": 0.0, 
                "Labels": []
            }
        
        pred_names = [p[0].lower() for p in preds]
        gt_names = [g.lower() for g in gt_set]
        
        # Calculate similarity matrix
        cosine_scores = vector_db.calculate_similarity(pred_names, gt_names)
        
        # Recall (Unique GT)
        gt_hits_max, _ = torch.max(cosine_scores, dim=0)
        recovered_gt_count = (gt_hits_max > 0.9).sum().item()
        recall = recovered_gt_count / len(gt_set)
        
        # Precision & Labels
        pred_hits_max, _ = torch.max(cosine_scores, dim=1)
        labels = (pred_hits_max > 0.9).cpu().numpy().astype(int)
        
        # P@1
        p1 = sum(labels[:1]) / 1.0 if len(labels) >= 1 else 0
        
        # P@10
        if len(labels) >= 10:
            p10 = sum(labels[:10]) / 10.0
        else:
            p10 = sum(labels) / 10.0
        
        # R@1
        r1 = sum(labels[:1]) / len(gt_set) if len(gt_set) > 0 else 0
        
        return {
            "Recall": recall, 
            "P@1": p1, 
            "P@10": p10, 
            "R@1": r1, 
            "R@10": recall, 
            "Labels": labels
        }
    
    @staticmethod
    def aggregate_metrics(results_list):
        """
        Aggregate metrics across multiple experiments
        
        Args:
            results_list (list): List of experiment results
            
        Returns:
            dict: Aggregated metrics
        """
        if not results_list:
            return {}
        
        # Calculate averages
        metrics = {
            'avg_rag_p1': sum(item['RAG_P@1'] for item in results_list) / len(results_list),
            'avg_rag_p10': sum(item['RAG_P@10'] for item in results_list) / len(results_list),
            'avg_rag_r1': sum(item['RAG_R@1'] for item in results_list) / len(results_list),
            'avg_rag_r10': sum(item['RAG_R@10'] for item in results_list) / len(results_list),
            'avg_gpt_p1': sum(item['GPT_P@1'] for item in results_list) / len(results_list),
            'avg_gpt_p10': sum(item['GPT_P@10'] for item in results_list) / len(results_list),
            'avg_gpt_r1': sum(item['GPT_R@1'] for item in results_list) / len(results_list),
            'avg_gpt_r10': sum(item['GPT_R@10'] for item in results_list) / len(results_list)
        }
        
        return metrics
