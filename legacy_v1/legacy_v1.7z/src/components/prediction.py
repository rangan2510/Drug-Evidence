"""
Prediction engines for RAG and baseline models
"""

import re
import time
import json
from config.settings import (
    TOP_K_LIMIT, 
    WEIGHT_RETRIEVAL, 
    WEIGHT_LLM, 
    THRESHOLD_FINAL,
    MAX_RETRIES,
    RETRY_WAIT_TIME
)


class PredictionEngine:
    """
    Handles predictions using RAG and baseline models
    """
    
    def __init__(self, vector_db, llm_rag, openai_client):
        """
        Initialize prediction engines
        
        Args:
            vector_db: Vector database instance
            llm_rag: LangChain LLM for RAG
            openai_client: OpenAI client for baseline
        """
        self.vector_db = vector_db
        self.llm_rag = llm_rag
        self.openai_client = openai_client
    
    def run_graph_rag(self, drug_name, associations, documents, synonyms=[]):
        """
        Run RAG prediction for drug-disease associations
        
        Args:
            drug_name (str): Name of the drug
            associations (list): List of target-disease associations
            documents (list): List of document chunks
            synonyms (list): List of drug synonyms
            
        Returns:
            list: List of (disease_name, score) tuples
        """
        if not documents:
            return []
        
        print(f"    🧠 Scoring {len(associations)} candidates using {len(documents)} docs...")
        
        # Index documents
        self.vector_db.index_documents(documents)
        
        results = []
        synonym_text = ", ".join(synonyms) if synonyms else "None"
        
        for i, assoc in enumerate(associations):
            query = f"Can {drug_name} treat {assoc['disease_name']} through {assoc['target_sym']}?"
            hits = self.vector_db.search(query, limit=3)
            
            if hits:
                retrieval_score = hits[0].score
                
                if retrieval_score > 0.4:
                    context = "\n".join([f"- {h.payload['text']}" for h in hits])
                    prompt = f"""
                    Verify drug-disease link: {drug_name} -> {assoc['disease_name']}.
                    Synonyms: {synonym_text}
                    Evidence: {context}
                    Return JSON only: {{ "confidence": <0-100 integer> }}
                    """
                    
                    # Retry logic for API calls
                    for attempt in range(MAX_RETRIES):
                        try:
                            resp = self.llm_rag.invoke(prompt).content
                            num_match = re.search(r'\d+', resp)
                            llm_val = int(num_match.group()) if num_match else 0
                            final_score = (retrieval_score * WEIGHT_RETRIEVAL) + ((llm_val/100) * WEIGHT_LLM)
                            
                            if final_score > THRESHOLD_FINAL:
                                print(f"      ✅ VERIFIED: {assoc['disease_name']} (S:{final_score:.2f})", flush=True)
                                results.append((assoc['disease_name'], final_score))
                            break
                            
                        except Exception as e:
                            if "429" in str(e):
                                wait_time = (attempt + 1) * RETRY_WAIT_TIME
                                print(f"      ⏳ OpenAI Rate Limit. Waiting {wait_time}s...", flush=True)
                                time.sleep(wait_time)
                            else:
                                print(f"      ❌ LLM Error: {e}", flush=True)
                                break
                    
                    time.sleep(0.5)  # Rate limiting
        
        # Sort and deduplicate results
        results.sort(key=lambda x: x[1], reverse=True)
        unique_res = {}
        for name, score in results:
            if name not in unique_res:
                unique_res[name] = score
        
        return list(unique_res.items())[:TOP_K_LIMIT]
    
    def run_llm_baseline(self, drug_name):
        """
        Run baseline GPT prediction
        
        Args:
            drug_name (str): Name of the drug
            
        Returns:
            list: List of (disease_name, score) tuples
        """
        prompt = f"""
        List the top 10 diseases treated by the drug {drug_name}.
        Return strictly a JSON list of strings: ["disease1", "disease2", ...]
        """
        
        try:
            resp = self.openai_client.chat.completions.create(
                model="gpt-4o",
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            
            data = json.loads(resp.choices[0].message.content)
            items = list(data.values())[0] if isinstance(data, dict) else data
            
            # Grade the top 10 (1.0 down to 0.1)
            graded_results = []
            for i, item in enumerate(items[:TOP_K_LIMIT]):
                score = 1.0 - (i * 0.1)
                if score <= 0:
                    score = 0.01
                graded_results.append((item, score))
            
            return graded_results
            
        except Exception as e:
            print(f"    ❌ GPT Baseline Error: {e}")
            return []
