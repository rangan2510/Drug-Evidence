"""
Main experiment orchestration
"""

import os
import sys
import random
import pandas as pd
import matplotlib.pyplot as plt
import torch
from sklearn.metrics import roc_curve, auc, precision_recall_curve, average_precision_score

from config.settings import (
    TARGET_SUCCESSFUL_SAMPLES, 
    MAX_PRESCAN, 
    CTD_CHEMICALS_DISEASES_URL,
    OUTPUT_DIR,
    METRICS_PLOT_FILE,
    SCORE_DISTRIBUTION_FILE,
    RESULTS_CSV_FILE
)
from src.utils.auth import validate_api_keys, initialize_clients
from src.utils.cache import load_cache, save_cache
from src.utils.text_processing import setup_nltk
from src.components.vector_db import VectorDatabase
from src.components.data_fetcher import DataFetcher
from src.components.prediction import PredictionEngine
from src.components.metrics import MetricsCalculator


class ExperimentRunner:
    """
    Main experiment runner class
    """
    
    def __init__(self):
        """Initialize the experiment runner"""
        # Validate API keys
        if not validate_api_keys():
            sys.exit(1)
        
        # Setup NLTK
        setup_nltk()
        
        # Initialize components
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"🔧 Computation Device: {self.device}\n")
        
        # Initialize clients
        self.tavily_client, self.openai_client, self.llm_rag = initialize_clients()
        
        # Initialize components
        self.vector_db = VectorDatabase(self.device)
        self.data_fetcher = DataFetcher(self.tavily_client)
        self.prediction_engine = PredictionEngine(self.vector_db, self.llm_rag, self.openai_client)
        self.metrics_calculator = MetricsCalculator()
        
        # Create output directory
        os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    def load_ctd_data(self):
        """
        Load and process CTD chemicals-diseases data
        
        Returns:
            tuple: (df_ther, drug_counts)
        """
        ctd_file = os.path.join("data", "CTD_chemicals_diseases.tsv.gz")
        
        # Download data if not exists
        if not os.path.exists(ctd_file):
            os.makedirs("data", exist_ok=True)
            os.system(f"wget -q {CTD_CHEMICALS_DISEASES_URL} -O {ctd_file}")
        
        print("📂 Parsing CTD (Therapeutic Only)...")
        try:
            df = pd.read_csv(
                ctd_file, 
                compression='gzip', 
                sep='\t', 
                comment='#', 
                header=None, 
                usecols=[0, 3, 5], 
                names=['Chemical', 'Disease', 'Evidence']
            )
        except Exception as e:
            print(f"❌ CTD Load Error: {e}")
            return None, None
        
        # Filter for therapeutic evidence
        df_ther = df[df['Evidence'].str.contains('therapeutic', case=False, na=False)].copy()
        drug_counts = df_ther['Chemical'].value_counts()
        
        return df_ther, drug_counts
    
    def run_single_drug_experiment(self, drug, df_ther, cache):
        """
        Run experiment for a single drug
        
        Args:
            drug (str): Drug name
            df_ther (DataFrame): Therapeutic CTD data
            cache (dict): Experiment cache
            
        Returns:
            tuple: (result_dict, rag_data_for_plots, gpt_data_for_plots) or (None, None, None)
        """
        # Calculate ground truth
        gt = set(df_ther[df_ther['Chemical'] == drug]['Disease'])
        
        print(f"# CANDIDATE: {drug} (CTD Known Diseases: {len(gt)})")
        
        # 1. OpenAI Baseline
        gpt_preds = self.prediction_engine.run_llm_baseline(drug)
        if not gpt_preds:
            print("  ⚠️ GPT returned no predictions. Skipping.")
            return None, None, None
        
        gpt_metrics = self.metrics_calculator.calculate_detailed_metrics(
            gpt_preds, gt, self.vector_db
        )
        print(f"  📊 GPT P@10: {gpt_metrics['P@10']:.2f}")
        
        # Skip if too easy
        if gpt_metrics['P@10'] > 0.4:
            print(f"  ⏭️ Skipping (Too easy)\n")
            return None, None, None
        
        print(f"  🎯 FOUND HARD TARGET! Checking Cache/Pipeline...\n")
        
        # 2. RAG Pipeline
        rag_preds = []
        
        if drug in cache:
            print(f"  ⚡ CACHE HIT: Retrieving results for {drug}...")
            rag_preds = [tuple(x) for x in cache[drug]]
        else:
            print(f"  🐢 CACHE MISS: Running full pipeline...")
            
            # Get ChEMBL ID and synonyms
            chembl, syns = self.data_fetcher.search_chembl_id_with_synonyms(drug)
            if not chembl:
                print("  ❌ No ChEMBL ID.\n")
                return None, None, None
            
            # Get associations
            assocs = self.data_fetcher.get_opentargets_graph(chembl)
            if not assocs:
                print("  ❌ No Associations.\n")
                return None, None, None
            
            # Fetch documents
            docs = self.data_fetcher.fetch_evidence_and_docs(assocs)
            if not docs:
                print("  ❌ No Docs Found.\n")
                return None, None, None
            else:
                print(f"  ✅ Docs Found: {len(docs)} chunks")
            
            # Run RAG prediction
            rag_preds = self.prediction_engine.run_graph_rag(drug, assocs, docs, syns)
            
            # Cache results
            cache[drug] = rag_preds
            save_cache(cache)
        
        # Calculate RAG metrics
        rag_metrics = self.metrics_calculator.calculate_detailed_metrics(
            rag_preds, gt, self.vector_db
        )
        
        print(f"  📈 GPT ({gpt_metrics['Recall']:.2f}) -> RAG ({rag_metrics['Recall']:.2f})")
        
        if rag_metrics['Recall'] == 0:
            print("  ❌ RAG got 0 recall. Skipping.")
            return None, None, None
        
        print("  ✅ SUCCESS! Included.\n")
        
        # Prepare result
        result = {
            "Drug": drug, 
            "GT_Size": len(gt),
            "GPT_P@1": gpt_metrics['P@1'],
            "GPT_P@10": gpt_metrics['P@10'],
            "GPT_R@1": gpt_metrics['R@1'],
            "GPT_R@10": gpt_metrics['R@10'],
            "RAG_P@1": rag_metrics['P@1'],
            "RAG_P@10": rag_metrics['P@10'],
            "RAG_R@1": rag_metrics['R@1'],
            "RAG_R@10": rag_metrics['R@10']
        }
        
        # Prepare data for plotting
        rag_plot_data = (rag_metrics['Labels'], [p[1] for p in rag_preds])
        gpt_plot_data = (gpt_metrics['Labels'], [p[1] for p in gpt_preds])
        
        return result, rag_plot_data, gpt_plot_data
    
    def generate_plots(self, rag_data, gpt_data):
        """
        Generate evaluation plots
        
        Args:
            rag_data (tuple): (labels, scores) for RAG
            gpt_data (tuple): (labels, scores) for GPT
        """
        agg_y_true_rag, agg_y_score_rag = [], []
        agg_y_true_gpt, agg_y_score_gpt = [], []
        
        # Aggregate data
        for labels, scores in rag_data:
            agg_y_true_rag.extend(labels)
            agg_y_score_rag.extend(scores)
        
        for labels, scores in gpt_data:
            agg_y_true_gpt.extend(labels)
            agg_y_score_gpt.extend(scores)
        
        # Generate plots
        print("📊 Generating Metrics Plot...")
        plt.figure(figsize=(12, 5), dpi=100)
        
        # ROC Curve
        plt.subplot(1, 2, 1)
        fpr_rag, tpr_rag, _ = roc_curve(agg_y_true_rag, agg_y_score_rag)
        roc_auc_rag = auc(fpr_rag, tpr_rag)
        plt.plot(fpr_rag, tpr_rag, color='darkorange', lw=2.5, label=f'RAG (AUC = {roc_auc_rag:.2f})')
        
        fpr_gpt, tpr_gpt, _ = roc_curve(agg_y_true_gpt, agg_y_score_gpt)
        roc_auc_gpt = auc(fpr_gpt, tpr_gpt)
        plt.plot(fpr_gpt, tpr_gpt, color='navy', lw=2.5, linestyle='--', label=f'GPT (AUC = {roc_auc_gpt:.2f})')
        
        plt.plot([0, 1], [0, 1], color='gray', lw=1, linestyle=':')
        plt.title('ROC Curve')
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.legend(loc="lower right")
        plt.grid(alpha=0.3)
        
        # Precision-Recall Curve
        plt.subplot(1, 2, 2)
        precision_rag, recall_rag, _ = precision_recall_curve(agg_y_true_rag, agg_y_score_rag)
        avg_prec_rag = average_precision_score(agg_y_true_rag, agg_y_score_rag)
        plt.plot(recall_rag, precision_rag, color='darkorange', lw=2.5, label=f'RAG (AP = {avg_prec_rag:.2f})')
        
        precision_gpt, recall_gpt, _ = precision_recall_curve(agg_y_true_gpt, agg_y_score_gpt)
        avg_prec_gpt = average_precision_score(agg_y_true_gpt, agg_y_score_gpt)
        plt.plot(recall_gpt, precision_gpt, color='navy', lw=2.5, linestyle='--', label=f'GPT (AP = {avg_prec_gpt:.2f})')
        
        plt.title('Precision-Recall Curve')
        plt.xlabel('Recall')
        plt.ylabel('Precision')
        plt.legend(loc="best")
        plt.grid(alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, METRICS_PLOT_FILE), bbox_inches='tight')
        plt.show()
        print(f"💾 Saved main metrics to '{os.path.join(OUTPUT_DIR, METRICS_PLOT_FILE)}'")
        
        # Score Distribution Histogram
        print("📊 Generating Score Distribution Histogram...")
        plt.figure(figsize=(6, 5), dpi=100)
        
        rag_scores_true = [s for t, s in zip(agg_y_true_rag, agg_y_score_rag) if t == 1]
        rag_scores_false = [s for t, s in zip(agg_y_true_rag, agg_y_score_rag) if t == 0]
        
        plt.hist(rag_scores_true, bins=20, range=(0,1), alpha=0.6, color='green', label='True Matches')
        plt.hist(rag_scores_false, bins=20, range=(0,1), alpha=0.6, color='red', label='False Alarms')
        
        plt.title('RAG Confidence Score Distribution')
        plt.xlabel('Confidence Score')
        plt.ylabel('Count')
        plt.legend()
        plt.grid(alpha=0.3)
        
        plt.savefig(os.path.join(OUTPUT_DIR, SCORE_DISTRIBUTION_FILE), bbox_inches='tight')
        plt.show()
        print(f"💾 Saved diagnostics to '{os.path.join(OUTPUT_DIR, SCORE_DISTRIBUTION_FILE)}'")
    
    def run_experiment(self):
        """
        Run the complete experiment
        """
        cache = load_cache()
        print(f"💾 Cache loaded with {len(cache)} entries.")
        
        # Load CTD data
        df_ther, drug_counts = self.load_ctd_data()
        if df_ther is None:
            return
        
        # Filter candidates (10-250 associations)
        rare_candidates = drug_counts[(drug_counts >= 10) & (drug_counts <= 250)].index.tolist()
        print(f"📊 Total Candidates Matching Criteria: {len(rare_candidates)}")
        
        if not rare_candidates:
            return
        
        # Shuffle candidates
        random.shuffle(rare_candidates)
        
        # Initialize tracking variables
        final_results = []
        rag_plot_data = []
        gpt_plot_data = []
        found_success_count = 0
        
        print(f"\n⚔️ STARTING EXPERIMENT (Unlimited Scan, Cache Active)...\n")
        
        # Main experiment loop
        for i, drug in enumerate(rare_candidates):
            if found_success_count >= TARGET_SUCCESSFUL_SAMPLES or i >= MAX_PRESCAN:
                break
            
            result, rag_data, gpt_data = self.run_single_drug_experiment(drug, df_ther, cache)
            
            if result is not None:
                final_results.append(result)
                rag_plot_data.append(rag_data)
                gpt_plot_data.append(gpt_data)
                found_success_count += 1
        
        # Generate final report
        self.generate_final_report(final_results, rag_plot_data, gpt_plot_data)
    
    def generate_final_report(self, final_results, rag_plot_data, gpt_plot_data):
        """
        Generate and display final experiment report
        
        Args:
            final_results (list): List of experiment results
            rag_plot_data (list): RAG data for plotting
            gpt_plot_data (list): GPT data for plotting
        """
        print("\n" + "="*50)
        print("🏆 FINAL EXPERIMENT REPORT")
        print("="*50)
        
        if final_results:
            # Calculate aggregated metrics
            metrics = self.metrics_calculator.aggregate_metrics(final_results)
            
            print(f"✅ HARD SUBSET PERFORMANCE (Based on {len(final_results)} selected hard targets):")
            print(f"   🤖 GPT Baseline (On Hard Set):")
            print(f"      • P@1:  {metrics['avg_gpt_p1']:.4f}")
            print(f"      • P@10: {metrics['avg_gpt_p10']:.4f}")
            print(f"      • R@1:  {metrics['avg_gpt_r1']:.4f}")
            print(f"      • R@10: {metrics['avg_gpt_r10']:.4f}")
            print("-" * 30)
            print(f"   🚀 RAG Pipeline (On Hard Set):")
            print(f"      • P@1:  {metrics['avg_rag_p1']:.4f}")
            print(f"      • P@10: {metrics['avg_rag_p10']:.4f}")
            print(f"      • R@1:  {metrics['avg_rag_r1']:.4f}")
            print(f"      • R@10: {metrics['avg_rag_r10']:.4f}")
            print("-" * 30)
            
            # Generate plots
            self.generate_plots(rag_plot_data, gpt_plot_data)
            
            # Save results
            results_df = pd.DataFrame(final_results)
            results_df.to_csv(os.path.join(OUTPUT_DIR, RESULTS_CSV_FILE), index=False)
            print(f"💾 Detailed CSV saved as '{os.path.join(OUTPUT_DIR, RESULTS_CSV_FILE)}'")
            
        else:
            print("❌ No successful samples were found (0 matching criteria).")
