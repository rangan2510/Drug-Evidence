"""
Vector database operations using Qdrant
"""

import torch
from sentence_transformers import SentenceTransformer, models, util
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct
from config.settings import (
    DOC_ENCODER_MODEL, 
    QUERY_ENCODER_MODEL, 
    COLLECTION_NAME, 
    VECTOR_SIZE, 
    DISTANCE_METRIC
)


class VectorDatabase:
    """
    Vector database wrapper for Qdrant operations
    """
    
    def __init__(self, device="cpu"):
        """
        Initialize vector database and encoders
        
        Args:
            device (str): Computation device ('cuda' or 'cpu')
        """
        self.device = device
        self.client = QdrantClient(":memory:")
        self._setup_encoders()
    
    def _setup_encoders(self):
        """Setup document and query encoders"""
        print("⚙️ Loading Encoders...")
        
        # Document encoder
        word_embedding_doc = models.Transformer(DOC_ENCODER_MODEL)
        pooling_doc = models.Pooling(
            word_embedding_doc.get_word_embedding_dimension(), 
            pooling_mode='cls'
        )
        self.doc_encoder = SentenceTransformer(
            modules=[word_embedding_doc, pooling_doc], 
            device=self.device
        )
        
        # Query encoder
        word_embedding_query = models.Transformer(QUERY_ENCODER_MODEL)
        pooling_query = models.Pooling(
            word_embedding_query.get_word_embedding_dimension(), 
            pooling_mode='cls'
        )
        self.query_encoder = SentenceTransformer(
            modules=[word_embedding_query, pooling_query], 
            device=self.device
        )
    
    def create_collection(self):
        """Create or recreate the vector collection"""
        if self.client.collection_exists(COLLECTION_NAME):
            self.client.delete_collection(COLLECTION_NAME)
        
        self.client.create_collection(
            COLLECTION_NAME, 
            vectors_config=VectorParams(size=VECTOR_SIZE, distance=getattr(Distance, DISTANCE_METRIC))
        )
    
    def index_documents(self, documents):
        """
        Index documents into the vector database
        
        Args:
            documents (list): List of Document objects
        """
        if not documents:
            return
        
        self.create_collection()
        
        # Generate embeddings
        embeddings = self.doc_encoder.encode(
            [d.page_content for d in documents], 
            convert_to_numpy=True, 
            show_progress_bar=False
        )
        
        # Create points for Qdrant
        points = [
            PointStruct(
                id=i, 
                vector=embeddings[i].tolist(), 
                payload={
                    "text": documents[i].page_content, 
                    "pmid": documents[i].metadata.get("pmid")
                }
            ) 
            for i in range(len(documents))
        ]
        
        # Upsert to database
        self.client.upsert(COLLECTION_NAME, points)
    
    def search(self, query, limit=3):
        """
        Search for similar documents
        
        Args:
            query (str): Search query
            limit (int): Number of results to return
            
        Returns:
            list: Search results
        """
        query_vector = self.query_encoder.encode(query).tolist()
        hits = self.client.query_points(
            COLLECTION_NAME, 
            query=query_vector, 
            limit=limit
        ).points
        
        return hits
    
    def calculate_similarity(self, pred_names, gt_names):
        """
        Calculate cosine similarity between predictions and ground truth
        
        Args:
            pred_names (list): List of predicted names
            gt_names (list): List of ground truth names
            
        Returns:
            torch.Tensor: Cosine similarity matrix
        """
        pred_emb = self.query_encoder.encode(
            pred_names, 
            convert_to_tensor=True, 
            show_progress_bar=False
        )
        gt_emb = self.query_encoder.encode(
            gt_names, 
            convert_to_tensor=True, 
            show_progress_bar=False
        )
        
        return util.cos_sim(pred_emb, gt_emb)
