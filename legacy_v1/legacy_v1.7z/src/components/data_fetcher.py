"""
Data fetching utilities for external APIs
"""

import re
import time
import requests
import xml.etree.ElementTree as ET
from config.settings import (
    OPENTARGETS_API_URL, 
    CHEMBL_API_BASE_URL, 
    PUBMED_EFETCH_URL, 
    REQUEST_HEADERS,
    REQUEST_TIMEOUT,
    MAX_RETRIES,
    RETRY_WAIT_TIME
)


class DataFetcher:
    """
    Handles data fetching from various biomedical APIs
    """
    
    def __init__(self, tavily_client):
        """
        Initialize with Tavily client
        
        Args:
            tavily_client: Tavily search client
        """
        self.tavily_client = tavily_client
    
    def search_chembl_id_with_synonyms(self, drug_name):
        """
        Search for ChEMBL ID and synonyms for a drug
        
        Args:
            drug_name (str): Name of the drug
            
        Returns:
            tuple: (chembl_id, synonyms_list)
        """
        try:
            print(f"    🔍 Searching ChEMBL ID for: {drug_name}...")
            query = f"official ChEMBL ID for drug {drug_name}"
            res = self.tavily_client.search(query, max_results=1, search_depth="basic")
            text = res['results'][0]['content']
            
            match = re.search(r'CHEMBL\d+', text)
            if not match:
                print(f"    ⚠️ No CHEMBL ID pattern found in search text.")
                return None, []
            
            chembl_id = match.group(0)
            synonyms = []
            
            # Fetch synonyms from ChEMBL API
            try:
                url = f"{CHEMBL_API_BASE_URL}/{chembl_id}?format=json"
                r = requests.get(url, timeout=REQUEST_TIMEOUT)
                if r.status_code == 200:
                    data = r.json()
                    if 'molecule_synonyms' in data:
                        synonyms = [
                            s['molecule_synonym'] 
                            for s in data['molecule_synonyms']
                        ]
                        synonyms = list(set(synonyms))[:5]  # Limit to 5 unique synonyms
            except:
                pass
            
            return chembl_id, synonyms
            
        except Exception as e:
            print(f"    ❌ Tavily Search Error: {e}")
            return None, []
    
    def get_opentargets_graph(self, chembl_id, max_targets=50):
        """
        Get target-disease associations from OpenTargets
        
        Args:
            chembl_id (str): ChEMBL identifier
            max_targets (int): Maximum number of targets to fetch
            
        Returns:
            list: List of target-disease associations
        """
        print(f"    🌐 Querying OpenTargets for {chembl_id}...")
        
        query = f"""
        query {{ 
            drug(chemblId: "{chembl_id}") {{ 
                knownDrugs(size: 20) {{ 
                    rows {{ 
                        target {{ id approvedSymbol }} 
                        disease {{ id name }} 
                    }} 
                }} 
            }} 
        }}
        """
        
        try:
            r = requests.post(
                OPENTARGETS_API_URL, 
                json={"query": query}, 
                timeout=REQUEST_TIMEOUT
            )
            
            if r.status_code != 200:
                print(f"    ❌ OpenTargets API Error: {r.status_code}")
                return []
            
            json_resp = r.json()
            data = json_resp.get('data') or {}
            drug = data.get('drug') or {}
            known = drug.get('knownDrugs') or {}
            rows = known.get('rows', [])
            
            if not rows:
                print(f"    ⚠️ No 'knownDrugs' rows returned.")
                return []
            
            associations = []
            seen = set()
            
            for row in rows:
                try:
                    t_sym = row.get('target', {}).get('approvedSymbol')
                    d_name = row.get('disease', {}).get('name')
                    
                    if t_sym and d_name:
                        pair = (t_sym, d_name)
                        if pair not in seen:
                            associations.append({
                                "target_id": row['target']['id'], 
                                "target_sym": t_sym,
                                "disease_id": row['disease']['id'], 
                                "disease_name": d_name
                            })
                            seen.add(pair)
                            if len(associations) >= max_targets:
                                break
                except:
                    continue
            
            return associations
            
        except Exception as e:
            print(f"    ❌ OpenTargets Exception: {e}")
            return []
    
    def fetch_evidence_and_docs(self, associations):
        """
        Fetch evidence documents for associations
        
        Args:
            associations (list): List of target-disease associations
            
        Returns:
            list: List of document chunks
        """
        from src.utils.text_processing import chunk_text_by_sentences
        
        all_chunks = []
        total_assocs = len(associations)
        print(f"    🔎 Checking evidence for ALL {total_assocs} associations...")
        
        for i, assoc in enumerate(associations):
            print(f"      [{i+1}/{total_assocs}] Checking: {assoc['target_sym']} -> {assoc['disease_name']}")
            
            query = """
            query($efoId: String!, $ensemblId: String!) { 
                disease(efoId: $efoId) { 
                    evidences(ensemblIds: [$ensemblId], datasourceIds: ["europepmc"], size: 10) { 
                        rows { literature } 
                    } 
                } 
            }
            """
            
            try:
                vars = {"efoId": assoc['disease_id'], "ensemblId": assoc['target_id']}
                r = requests.post(
                    OPENTARGETS_API_URL, 
                    json={"query": query, "variables": vars}, 
                    timeout=3
                )
                json_resp = r.json()
                
                data = json_resp.get('data') or {}
                disease = data.get('disease') or {}
                evidences = disease.get('evidences') or {}
                rows = evidences.get('rows', [])
                
                if not rows:
                    continue
                
                # Extract PMIDs
                pmids = set()
                for row in rows:
                    if row.get('literature'):
                        pmids.update([str(x) for x in row['literature']])
                
                if not pmids:
                    continue
                
                # Fetch documents from PubMed
                docs_found = False
                for pmid in list(pmids)[:3]:  # Limit to 3 PMIDs
                    try:
                        url = f"{PUBMED_EFETCH_URL}?db=pubmed&id={pmid}&rettype=abstract&retmode=xml"
                        r_pm = requests.get(url, headers=REQUEST_HEADERS, timeout=3)
                        
                        if r_pm.status_code == 200:
                            root = ET.fromstring(r_pm.text)
                            texts = [t.text for t in root.findall('.//AbstractText') if t.text]
                            if texts:
                                chunks = chunk_text_by_sentences(
                                    " ".join(texts), pmid, "PubMed"
                                )
                                all_chunks.extend(chunks)
                                docs_found = True
                    except:
                        pass
                
                if docs_found:
                    print(f"        ✅ Retrieved {len(all_chunks)} chunks so far...")
                    
            except Exception as e:
                print(f"        ❌ Evidence Fetch Error: {str(e)}")
                pass
        
        return all_chunks
