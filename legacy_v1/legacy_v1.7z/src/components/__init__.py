"""
Core components for the RAG system
"""
