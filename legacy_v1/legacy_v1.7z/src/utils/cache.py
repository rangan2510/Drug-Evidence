"""
Caching utilities for experiment results
"""

import json
import os
from config.settings import CACHE_FILE


def load_cache():
    """
    Load experiment cache from file
    
    Returns:
        dict: Cache data dictionary
    """
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, 'r') as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️ Cache Load Error: {e}")
            return {}
    return {}


def save_cache(cache_data):
    """
    Save experiment cache to file
    
    Args:
        cache_data (dict): Cache data to save
    """
    try:
        with open(CACHE_FILE, 'w') as f:
            json.dump(cache_data, f, indent=2)
    except Exception as e:
        print(f"⚠️ Cache Save Error: {e}")


def clear_cache():
    """
    Clear the experiment cache file
    """
    if os.path.exists(CACHE_FILE):
        os.remove(CACHE_FILE)
        print("✅ Cache cleared successfully")
    else:
        print("ℹ️ No cache file found")
