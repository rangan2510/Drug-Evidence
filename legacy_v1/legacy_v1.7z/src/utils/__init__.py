"""
Utility functions for the RAG system
"""
