"""
Authentication and client initialization utilities
"""

import sys
from openai import OpenAI
from tavily import TavilyClient
from langchain_openai import ChatOpenAI
from config.settings import OPENAI_API_KEY, TAVILY_API_KEY, LLM_MODEL, LLM_TEMPERATURE


def initialize_clients():
    """
    Initialize all API clients with proper error handling
    
    Returns:
        tuple: (tavily_client, openai_client, llm_rag)
    """
    try:
        # Validate API keys
        if not OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY not found in environment variables")
        if not TAVILY_API_KEY:
            raise ValueError("TAVILY_API_KEY not found in environment variables")
        
        # Initialize clients
        tavily_client = TavilyClient(api_key=TAVILY_API_KEY)
        openai_client = OpenAI(api_key=OPENAI_API_KEY)
        
        # Initialize LLM for RAG
        llm_rag = ChatOpenAI(
            temperature=LLM_TEMPERATURE,
            model_name=LLM_MODEL,
            api_key=OPENAI_API_KEY
        )
        
        return tavily_client, openai_client, llm_rag
        
    except Exception as e:
        print(f"❌ Client Init Error: {e}")
        sys.exit(1)


def validate_api_keys():
    """
    Validate that all required API keys are present
    
    Returns:
        bool: True if all keys are valid, False otherwise
    """
    from config.settings import OPENAI_API_KEY, TAVILY_API_KEY, ENTREZ_EMAIL
    
    missing_keys = []
    if not OPENAI_API_KEY:
        missing_keys.append("OPENAI_API_KEY")
    if not TAVILY_API_KEY:
        missing_keys.append("TAVILY_API_KEY")
    if not ENTREZ_EMAIL:
        missing_keys.append("ENTREZ_EMAIL")
    
    if missing_keys:
        print(f"❌ Missing API keys: {', '.join(missing_keys)}")
        print("Please set these in your .env file")
        return False
    
    return True
