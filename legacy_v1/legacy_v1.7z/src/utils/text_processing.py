"""
Text processing and chunking utilities
"""

import nltk
from langchain_core.documents import Document
from config.settings import CHUNK_SIZE, CHUNK_OVERLAP


def setup_nltk():
    """
    Download required NLTK data
    """
    try:
        nltk.data.find('tokenizers/punkt')
    except:
        nltk.download('punkt', quiet=True)


def chunk_text_by_sentences(text, pmid, source, max_tokens=CHUNK_SIZE, overlap_tokens=CHUNK_OVERLAP):
    """
    Chunk text by sentences with overlap
    
    Args:
        text (str): Input text to chunk
        pmid (str): PubMed ID for metadata
        source (str): Source identifier
        max_tokens (int): Maximum tokens per chunk
        overlap_tokens (int): Overlap tokens between chunks
        
    Returns:
        list: List of Document objects
    """
    if not text or len(text.strip()) < 50:
        return []
    
    sentences = nltk.sent_tokenize(text)
    chunks = []
    current_chunk = []
    current_length = 0
    
    for sentence in sentences:
        sentence_tokens = len(sentence) // 4
        if current_length + sentence_tokens > max_tokens and current_chunk:
            chunks.append(" ".join(current_chunk))
            
            # Create overlap for next chunk
            overlap_sentences = []
            overlap_length = 0
            for sent in reversed(current_chunk):
                sent_tokens = len(sent) // 4
                if overlap_length + sent_tokens <= overlap_tokens:
                    overlap_sentences.insert(0, sent)
                    overlap_length += sent_tokens
                else:
                    break
            current_chunk = overlap_sentences
            current_length = overlap_length
        
        current_chunk.append(sentence)
        current_length += sentence_tokens
    
    if current_chunk:
        chunks.append(" ".join(current_chunk))
    
    # Create Document objects
    documents = []
    for idx, chunk in enumerate(chunks):
        doc = Document(
            page_content=chunk,
            metadata={
                "source": source, 
                "pmid": pmid, 
                "chunk_id": idx, 
                "total_chunks": len(chunks)
            }
        )
        documents.append(doc)
    
    return documents
