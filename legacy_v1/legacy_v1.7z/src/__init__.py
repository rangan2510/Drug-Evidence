"""
RAG-based Drug-Disease Association Discovery

A modular system for discovering mechanistic associations between drugs 
and diseases using retrieval-augmented generation.
"""

__version__ = "1.0.0"
__author__ = "Research Team"
