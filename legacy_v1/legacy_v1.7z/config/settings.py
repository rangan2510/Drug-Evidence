"""
Configuration settings for the RAG system
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Experiment Configuration
TARGET_SUCCESSFUL_SAMPLES = 50
MAX_PRESCAN = 400
CACHE_FILE = "experiment_cache.json"

# Pipeline Configuration
CHUNK_SIZE = 512
CHUNK_OVERLAP = 50
TOP_K_LIMIT = 10
WEIGHT_RETRIEVAL = 0.75
WEIGHT_LLM = 0.25
THRESHOLD_FINAL = 0.6

# Model Configuration
DOC_ENCODER_MODEL = "ncbi/MedCPT-Article-Encoder"
QUERY_ENCODER_MODEL = "ncbi/MedCPT-Query-Encoder"
LLM_MODEL = "gpt-4o"
LLM_TEMPERATURE = 0

# Vector Database Configuration
COLLECTION_NAME = "biomedical_trace"
VECTOR_SIZE = 768
DISTANCE_METRIC = "COSINE"

# API Configuration
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")
ENTREZ_EMAIL = os.getenv("ENTREZ_EMAIL")

# Data URLs
CTD_CHEMICALS_DISEASES_URL = "http://ctdbase.org/reports/CTD_chemicals_diseases.tsv.gz"
OPENTARGETS_API_URL = "https://api.platform.opentargets.org/api/v4/graphql"
CHEMBL_API_BASE_URL = "https://www.ebi.ac.uk/chembl/api/data/molecule"

# PubMed Configuration
PUBMED_EFETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
REQUEST_HEADERS = {
    'User-Agent': 'RAG-Bench',
    'From': ENTREZ_EMAIL
}

# Rate Limiting
MAX_RETRIES = 3
RETRY_WAIT_TIME = 2
REQUEST_TIMEOUT = 10

# Output Configuration
OUTPUT_DIR = "outputs"
METRICS_PLOT_FILE = "metrics_summary.png"
SCORE_DISTRIBUTION_FILE = "score_distribution.png"
RESULTS_CSV_FILE = "final_strict_results.csv"
