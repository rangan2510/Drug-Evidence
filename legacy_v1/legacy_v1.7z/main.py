#!/usr/bin/env python3
"""
Main entry point for the RAG-based drug-disease association discovery system

This script orchestrates the complete pipeline for discovering mechanistic
associations between drugs and diseases using retrieval-augmented generation.
"""

import sys
import os
import functools

# Add src directory to Python path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# FORCE UNBUFFERED OUTPUT
print = functools.partial(print, flush=True)

# Import torch for device detection
import torch

from src.components.experiment import ExperimentRunner


def main():
    """
    Main function to run the RAG experiment
    """
    print("=" * 60)
    print("🚀 MECHANISTIC ASSOCIATION DISCOVERY - CTD COUNT EDITION")
    print("=" * 60)
    print()
    
    # Check device
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"🔧 Computation Device: {device}")
    print()
    
    # Initialize and run experiment
    try:
        runner = ExperimentRunner()
        runner.run_experiment()
        
        print("\n" + "=" * 60)
        print("✅ EXPERIMENT COMPLETED SUCCESSFULLY")
        print("=" * 60)
        
    except KeyboardInterrupt:
        print("\n❌ Experiment interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Experiment failed with error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
